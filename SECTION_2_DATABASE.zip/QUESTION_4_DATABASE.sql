DROP PROCEDURE IF EXISTS starprint;
DELIMITER $$
CREATE PROCEDURE starprint()
BEGIN
    DECLARE CT INT(10) DEFAULT 1;
    DECLARE CH VARCHAR(256) DEFAULT "* ";
    CREATE TEMPORARY TABLE `output` (`rowno` INT, `pattern` VARCHAR(50));

    WHILE CT <= 20 DO
        INSERT INTO `output` (`rowno`,`pattern`) VALUES (CT,REPEAT(CH,CT));
        SET CT = CT +1;
    END WHILE;

    SELECT `pattern` FROM `output` ORDER BY `rowno` ASC;
    DROP TABLE `output`;
END$$
DELIMITER ;

CALL starprint();

        
/*Simple query using information_schema.tables*/
set @number = 0;
select repeat('* ', @number := @number + 1) from information_schema.tables limit 20;