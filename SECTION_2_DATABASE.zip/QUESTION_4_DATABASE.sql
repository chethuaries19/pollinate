DROP PROCEDURE IF EXISTS starprint;
DELIMITER $$
CREATE PROCEDURE starprint()
BEGIN
    DECLARE X INT(10) DEFAULT 1;
    DECLARE P VARCHAR(256) DEFAULT "* ";
    CREATE TEMPORARY TABLE TEMP (`rowno` INT, `pattern` VARCHAR(255));

    WHILE X <= 20 DO
        INSERT INTO TEMP (`rowno`,`pattern`) VALUES (X,REPEAT(P,X));
        SET X = X +1;
    END WHILE;

    SELECT `pattern` FROM TEMP ORDER BY `rowno` ASC;
    DROP TABLE TEMP;
END$$
DELIMITER ;

CALL starprint();

        
/*Simple query using information_schema.tables*/
set @number = 0;
select repeat('* ', @number := @number + 1) from information_schema.tables limit 20;