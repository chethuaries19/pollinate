
/*CREATING THE TABLE WITH NAME 'OCCUPATIONS'*/
CREATE TABLE OCCUPATIONS (
    NAME VARCHAR(255),
    OCCUPATION VARCHAR(255)
);

/*INSERTING THE VALUES TO OCCUPATIONS TABLE*/
INSERT INTO OCCUPATIONS(  NAME , OCCUPATION )
VALUES ('Samantha', 'Doctor'),
('Julia', 'Actor'),
('Maria', 'Actor'),
('Meera', 'Singer'),
('Ashley', 'Professor'),
('Ketty', 'Professor'),
('Christeen', 'Professor'),
('Jane', 'Actor'),
('Jenny', 'Doctor'),
('Priya', 'Singer')
;

COMMIT;/*TO COMMIT THE DATA INSERTED*/

/*Query to order the occurences alphabetically in specified format*/
SELECT 
    CONCAT(NAME, '(', LEFT(OCCUPATION, 1), ')') AS NameOcc
FROM
    OCCUPATIONS
ORDER BY Name;

/*Query to get number of occurences of occupation and occupation name in specified format*/
SELECT 
    CASE
        WHEN
            COUNT(OCCUPATION) > 1
        THEN
            CONCAT('There are total of ', COUNT(OCCUPATION), ' ', LOWER(OCCUPATION), 's')
        ELSE CONCAT('There are total of ', COUNT(OCCUPATION), ' ', LOWER(OCCUPATION))
    END AS NameOcc
FROM
    OCCUPATIONS B
GROUP BY OCCUPATION
ORDER BY COUNT(OCCUPATION) , Occupation ASC;

/*Single query clubbing both the test results*/
SELECT 
    *
FROM
    (SELECT 
        CONCAT(NAME, '(', LEFT(OCCUPATION, 1), ')') AS NameOcc
    FROM
        OCCUPATIONS 
	UNION ALL 
	SELECT 
        CASE
                WHEN COUNT(OCCUPATION) > 1 THEN CONCAT('There are total of ', COUNT(OCCUPATION), ' ', LOWER(OCCUPATION), 's')
                ELSE CONCAT('There are total of ', COUNT(OCCUPATION), ' ', LOWER(OCCUPATION))
		END AS NameOcc
    FROM
        OCCUPATIONS B
    GROUP BY OCCUPATION) C
ORDER BY NameOcc ASC;
