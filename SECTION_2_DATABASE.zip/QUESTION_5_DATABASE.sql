
DROP PROCEDURE IF EXISTS starprintReverse;
DELIMITER $$
CREATE PROCEDURE starprintReverse()
BEGIN
    DECLARE CT INT(10) DEFAULT 20;
    DECLARE CH VARCHAR(256) DEFAULT " *";
    CREATE TEMPORARY TABLE `output` (`rowno` INT, `pattern` VARCHAR(50));

    WHILE CT > 0 DO
        INSERT INTO `output` (`rowno`,`pattern`) VALUES (CT,REPEAT(CH,CT));
        SET CT = CT - 1;
    END WHILE;

    SELECT `pattern` FROM `output` ORDER BY `rowno` DESC;
    DROP TABLE `output`;
END$$
DELIMITER ;

CALL starprintReverse();

/*Simple query using information_schema.tables*/
set @number = 21;
select repeat('* ', @number := @number - 1) from information_schema.tables limit 20;


