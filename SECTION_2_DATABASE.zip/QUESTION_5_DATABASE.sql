
DROP PROCEDURE IF EXISTS starprintReverse;
DELIMITER $$
CREATE PROCEDURE starprintReverse()
BEGIN
    DECLARE X INT(10) DEFAULT 20;
    DECLARE P VARCHAR(255) DEFAULT " *";
    CREATE TEMPORARY TABLE TEMP (`rowno` INT, `pattern` VARCHAR(255));

    WHILE X > 0 DO
        INSERT INTO TEMP(`rowno`,`pattern`) VALUES (X,REPEAT(P,X));
        SET X = X - 1;
    END WHILE;

    SELECT `pattern` FROM TEMP ORDER BY `rowno` DESC;
    DROP TABLE TEMP;
END$$
DELIMITER ;

CALL starprintReverse();

/*Simple query using information_schema.tables*/
set @number = 21;
select repeat('* ', @number := @number - 1) from information_schema.tables limit 20;


